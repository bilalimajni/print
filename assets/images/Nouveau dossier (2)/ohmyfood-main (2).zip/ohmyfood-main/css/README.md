# ohmyfood
# ohmyfood
### Ma mission est de développer un site “mobile first” qui répertorie les menus de restaurants gastronomiques. En plus des systèmes classiques de réservation, les clients pourront composer le menu de leur repas pour que les plats soient prêts à leur arrivée. Finis, les temps d'attente au restaurant !


### site en ligne:https://stunning-truffle-250304.netlify.app
### Repositories github :https://github.com/bilalimajni/ohmyfood

![image](https://user-images.githubusercontent.com/119870794/219767610-b6fd9efa-7cc5-4994-bc3b-37d407a2f9ea.png)
![image](https://user-images.githubusercontent.com/119870794/219763859-47a13b48-1d38-44dd-b243-fc69ea423128.png)
![image](https://user-images.githubusercontent.com/119870794/219767610-b6fd9efa-7cc5-4994-bc3b-37d407a2f9ea.png)
